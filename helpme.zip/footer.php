<footer>
	<div class="inner-footer dark">

		
		
		<!-- End Contact -->
		<div id="back-to-top">
			<a href="#top">Back to Top</a>
		</div>
	</div>
	<!-- End inner Footer -->
<center>
	<div class="end-footer">
		<div class="lastdiv">
			<div class="copyright">
				© 2017-2018 HelpMeDr.in, All Rights Reserved | Powered By :- Lavega Infotech
			</div>

			<div class="f-socials">
				<a href="#"><img src="images/feed.png" alt=""></a>
				<a href="#"><img src="images/tweet.png" alt=""></a>
				<a href="#"><img src="images/fcb.png" alt=""></a>
				<a href="#"><img src="images/gplus.png" alt=""></a>
				<a href="#"><img src="images/pin.png" alt=""></a>
			</div>
		<div class="clear"></div>
		</div>
	</div>
	</center>
	</footer>