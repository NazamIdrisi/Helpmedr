<header>
		
		<div class="subheader clearfix">
			<div class="inner-subheader">
				<div class="phone">+91 8960176488</div>

				<div class="subheader2">
					<ul >
						<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About</a></li>
						<li><a href="#">Services </a></li>
						<ul class="sub-menu" style="display:none;">
							<li><a href="home-boxed.html">Home Boxed</a></li>
							<li><a href="home2.html">Home 2</a></li>
							<li><a href="home3.html">Home 3</a></li>
							<li><a href="home4.html">Home 4</a></li>
						</ul>
						<li><a href="contact.php">Contact</a></li>
						<li><a href="login.php">Login</a></li>
					</ul>				
				</div>
			</div>
		</div>

		<div class="row2">
		<div class="upper-header">
			
			<div class="logo">
				<center><a href="index.php"><img src="images/logo.png" alt="" style="height:50%;width:50%;"></a></center>
			</div>					
			
			<!-- Navigation -->
			<!---<nav id="nav">
				<ul id="navlist" class="sf-menu clearfix">
					<li class="current"><a href="index.html">Home</a>
						<ul class="sub-menu">
							<li><a href="home-boxed.html">Home Boxed</a></li>
							<li><a href="home2.html">Home 2</a></li>
							<li><a href="home3.html">Home 3</a></li>
							<li><a href="home4.html">Home 4</a></li>
						</ul>
					</li>
					<li><a href="about.html"> About Us</a></li>
					<li><a href="#">Features</a>
						<ul class="sub-menu">
							<li><a href="404.html">404 Page</a></li>
							<li><a href="grid.html">Grid Positions</a></li>
							<li><a href="typography.html">Typography</a></li>
						</ul>
					</li>
					<li><a href="portfolio.html">Portfolio</a></li>
					<li><a href="blog.html">Blog</a></li>
					<li><a href="testimonials.html">Testimonials</a></li>
					<li><a href="contact.html">Contact Us</a></li>
				</ul>
			</nav>---->
        	<!-- Navigation -->  
        	<div class="clear"></div>
       </div>  
       <!-- End Upper Header -->
       </div>
       <!-- End Row2 -->

	</header>