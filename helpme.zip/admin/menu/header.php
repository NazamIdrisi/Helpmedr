<div id="header" style="background-color:maroon;">
               <h1 id="logo-text"><a href=".">WebShoft | C-panel</a></h1>
                <div id="header-links">
                </div>
            </div>