<?php
	include("check.php");	
	include("mydbcon.php");
?>


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Doctor <small> Informatin </small>
                           <span ><a href="adddoctor.php" class="pull-right btn btn-primary"> Add Doctor</a></span>
                        </h1>
                    </div>
                </div>
                <!-- /.row -->

               
                <!-- /.row -->

              
                   
                <div class="row">
                  
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-money fa-fw"></i>All Doctors 
                                 </h3>
                                
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped bg-success">
                                        <thead>
                                            <tr class="bg-info">									

                                                <th> Doctor Id</th>
                                                <th> Doctor_name</th>
                                                <th> about</th>
                                                <th> mobile_number</th>
                                                <th> Education</th>
                                                <th> Specialities</th>
												<th> Expertise</th>
                                                <th> Achievements</th>
                                                <th> Practice Information</th>
                                                <th> Languages</th>
                                                <th> Address</th>
                                                <th> Doctor_password</th>
												<th> image_url</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										
  <?php
  
$sql = "select * from student";
$result = mysqli_query($db, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
                                             $id=$row['id'];
											 $Doct_id=$row['Doctor_id'];
											 $Doct_name=$row['Doctor_name'];
											 $Doct_father=$row['about'];
											 $Doct_email=$row['mobile_number'];
											 $Doct_number=$row['Education'];
											 $Doct_add=$row['Specialities'];
											 $Doct_course=$row['Expertise'];
											 $Doct_marks=$row['Achievements'];
											 $Doct_grade=$row['Practice Information'];
											 $Doct_roll=$row['Languages'];
											 $Doct_date=$row['Address'];
											 $Doct_pass=$row['Doctor_password'];
											 
											 echo "<tr>";
                                                echo "<td>"; echo $Doct_id; echo "</td>";
												echo "<td>"; echo $Doct_name; echo "</td>";
												echo "<td>"; echo $Doct_father; echo "</td>";
												echo "<td>"; echo $Doct_email; echo "</td>";
												echo "<td>"; echo $Doct_number; echo "</td>";
												echo "<td>"; echo $Doct_add; echo "</td>";
												echo "<td>"; echo $Doct_course; echo "</td>";
												echo "<td>"; echo $Doct_marks; echo "</td>";
												echo "<td>"; echo $Doct_grade; echo "</td>";
												echo "<td>"; echo $Doct_roll; echo "</td>";
												echo "<td>"; echo $Doct_date; echo "</td>";
												echo "<td>"; echo $Doct_pass; echo "</td>";
												 
                                             
                                                echo "<td>"; echo "<a href='update.php?id=$id' class='btn btn-danger'>UPDATE</a>"; echo "</td>";
                                               
                                            echo "</tr>";
    }
} else {
    echo "0 results";
}

mysqli_close($db);
?>
                                            
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                                <div class="text-right">
                                    <a href="#">View All Transactions <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
